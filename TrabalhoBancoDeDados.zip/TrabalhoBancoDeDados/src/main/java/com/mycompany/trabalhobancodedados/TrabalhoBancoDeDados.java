/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalhobancodedados;

import view.login;

/**
 *
 * @author lucas
 */
public class TrabalhoBancoDeDados {

    public static void main(String[] args) {
        new login().setVisible(true);
    }
}
