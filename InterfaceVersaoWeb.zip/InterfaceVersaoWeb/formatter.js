// Aguarda o documento HTML ser completamente carregado para executar o script
document.addEventListener('DOMContentLoaded', function() {

    // Encontra os campos de CPF e Telefone pelo ID
    const inputCpf = document.getElementById('cpf');
    const inputTelefone = document.getElementById('telefone');

    // Adiciona o "ouvinte" de eventos para o campo de CPF
    if (inputCpf) {
        inputCpf.addEventListener('input', function(e) {
            // Pega o valor atual, remove tudo que não for número
            let value = e.target.value.replace(/\D/g, '');

            // Aplica a máscara de CPF: 000.000.000-00
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');

            // Atualiza o valor no campo
            e.target.value = value;
        });
    }

    // Adiciona o "ouvinte" de eventos para o campo de Telefone
    if (inputTelefone) {
        inputTelefone.addEventListener('input', function(e) {
            // Pega o valor atual, remove tudo que não for número
            let value = e.target.value.replace(/\D/g, '');

            // Aplica a máscara de Telefone: (00) 00000-0000
            value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
            value = value.replace(/(\d{5})(\d)/, '$1-$2');

            // Atualiza o valor no campo
            e.target.value = value;
        });
    }

});