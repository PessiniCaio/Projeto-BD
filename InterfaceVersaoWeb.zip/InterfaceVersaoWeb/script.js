document.addEventListener('DOMContentLoaded', function() {
    // --- LÓGICA DE LOGIN ---
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const usuario = document.getElementById('usuario').value;
            const senha = document.getElementById('senha').value;

            if (usuario === 'admin' && senha === 'admin') {
                window.location.href = 'adminDashboard.html';
            } else if (usuario && senha) {
                window.location.href = 'userDashboard.html';
            } else {
                alert('Usuário ou senha inválidos!');
            }
        });
    }

    // --- LÓGICA DE NAVEGAÇÃO DO DASHBOARD ---
    const pageContentWrapper = document.getElementById('pageContentWrapper');
    if (pageContentWrapper) {

        // Função para carregar o conteúdo da página dinamicamente
        const loadPageContent = (pageFileName) => {
            console.log(`Tentando carregar a página: ${pageFileName}`);

            fetch(pageFileName) // Agora usa o nome do arquivo diretamente
                .then(response => {
                    if (!response.ok) { throw new Error(`Erro HTTP! Status: ${response.status}`); }
                    return response.text();
                })
                .then(data => {
                    pageContentWrapper.innerHTML = data;
                    console.log(`Página ${pageFileName} carregada com sucesso.`);
                })
                .catch(error => {
                    console.error('Falha ao carregar a página:', error);
                    pageContentWrapper.innerHTML = `<div class="container-fluid px-4"><div class="alert alert-danger mt-4"><h4>Erro 404</h4><p>O arquivo <strong>${pageFileName}</strong> não foi encontrado.</p></div></div>`;
                });
        };

        // Adiciona eventos de clique aos links de navegação
        const navLinks = document.querySelectorAll('#sidebar-wrapper [data-page]');
        navLinks.forEach(link => {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const targetPage = this.getAttribute('data-page');
                loadPageContent(targetPage);

                // Atualiza o item ativo no menu
                navLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // Trata o botão de logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (event) => {
                event.preventDefault();
                window.location.href = 'index.html';
            });
        }


        // Carrega a página inicial do dashboard
        loadPageContent('dashboardHome.html');
    }
});