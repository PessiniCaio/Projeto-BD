<?php
// Arquivo: conexao.php (Configuração para XAMPP Local)

// 1. Onde o banco de dados está. Para o XAMPP, é sempre 'localhost'.
$host = 'localhost';

// 2. O nome EXATO do banco de dados que você criou no phpMyAdmin.
$dbname = 'aulabd'; // <<-- VERIFIQUE SE ESSE É O NOME DO SEU BANCO

// 3. O usuário do MySQL. No XAMPP, o padrão é 'root'.
$user = 'root';

// 4. A senha do MySQL. No XAMPP, por padrão, a senha é VAZIA.
$password = ''; // <<-- DEIXE EM BRANCO, A MENOS QUE VOCÊ TENHA DEFINIDO UMA SENHA

// --- String de Conexão ---
$dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";

try {
    // Tenta criar a conexão
    $pdo = new PDO($dsn, $user, $password);

    // Configura o PDO para nos avisar sobre qualquer erro no SQL
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Se a conexão falhar, o script vai parar e mostrar o erro exato na tela.
    // Ex: "Access denied for user 'root'...", "Unknown database 'instituto_caramelo'..."
    die("<h1>Erro na Conexão com o Banco de Dados</h1><p>Não foi possível conectar ao MySQL. Verifique as configurações no arquivo `conexao.php`.</p><hr><p><strong>Mensagem do Erro:</strong> " . $e->getMessage() . "</p>");
}
?>