<?php
// Arquivo: conexao.php (para MySQL)

$host = 'localhost';
$dbname = 'aulabd'; // VERIFIQUE SE ESTÁ CORRETO
$user = 'root';   // VERIFIQUE SE ESTÁ CORRETO
$password = 'aluno'; // VERIFIQUE SE ESTÁ CORRETA

$dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Se chegou até aqui, a conexão funcionou.
    // echo "Conexão com o banco de dados bem-sucedida!"; // Descomente esta linha para testar a conexão diretamente.

} catch (PDOException $e) {
    // Se a conexão falhar, o script vai parar aqui e mostrar o erro exato.
    die("FALHA NA CONEXÃO: " . $e->getMessage());
}
?>