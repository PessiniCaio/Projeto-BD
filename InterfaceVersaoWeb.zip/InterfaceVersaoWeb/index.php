<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instituto Caramelo - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css"> </head>
<body class="d-flex align-items-center justify-content-center">

    <div class="login-container">
        <h2 class="text-center mb-4">Instituto Caramelo</h2>

        <?php
        // Exibe uma mensagem de erro se o login falhar
        if (isset($_GET['erro'])) {
            echo '<div class="alert alert-danger">Usuário ou senha inválidos. Tente novamente.</div>';
        }
        ?>

        <form action="login_process.php" method="POST">
            <div class="mb-3">
                <label for="usuario" class="form-label">Usuário</label>
                <input type="text" class="form-control" id="usuario" name="usuario" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" required>
            </div>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-block">Login</button>
                <a href="cadastro.html" class="btn btn-secondary btn-block">Cadastrar</a>
            </div>
        </form>
    </div>

</body>
</html>