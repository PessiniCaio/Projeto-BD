<?php
// Inclui a conexão com o banco de dados MySQL
require_once 'conexao.php';

// A função de contagem é a mesma
function contarRegistros($pdo, $tabela) {
    try {
        $sql = "SELECT COUNT(*) FROM $tabela";
        $stmt = $pdo->query($sql);
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

$totalPessoas = contarRegistros($pdo, 'Pessoa');
$totalAnimais = contarRegistros($pdo, 'Animal');
$totalAdocoes = contarRegistros($pdo, 'Adocao');
?>
<!DOCTYPE html>
<html lang="pt-br">
</html>