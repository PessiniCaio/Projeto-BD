<?php
// Força a exibição de qualquer erro para facilitar o diagnóstico
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Inclui sua conexão com o banco de dados
require_once 'conexao.php';

// Função genérica para contar registros em uma tabela
function contarRegistros($pdo, $tabela) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$tabela`");
        $stmt->execute();
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        // Exibe um alerta se a tabela não for encontrada
        echo "<div class='alert alert-danger m-3'>Erro ao acessar a tabela '<strong>$tabela</strong>'. Verifique se ela existe no banco de dados.</div>";
        return 0;
    }
}

// Função específica para contar registros com uma condição (WHERE)
function contarComCondicao($pdo, $tabela, $coluna, $valor) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$tabela` WHERE `$coluna` = ?");
        $stmt->execute([$valor]);
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger m-3'>Erro ao acessar a tabela '<strong>$tabela</strong>' com condição. Verifique se a coluna '<strong>$coluna</strong>' existe.</div>";
        return 0;
    }
}

// --- BUSCANDO OS DADOS PARA OS CARDS ---

// Contadores antigos
$totalPessoas = contarRegistros($pdo, 'Pessoa');
$totalAnimais = contarRegistros($pdo, 'Animal');
$totalAdocoes = contarRegistros($pdo, 'Adocao');

// NOVOS CONTADORES
$totalCastracoes = contarRegistros($pdo, 'Castracao');
$totalPatrocinadores = contarRegistros($pdo, 'Patrocinador');
$totalResgates = contarRegistros($pdo, 'Resgate');
// Para este contador, assumimos que o status no banco é "Em Tratamento".
// Se for diferente, basta alterar o valor aqui.
$totalEmTratamento = contarComCondicao($pdo, 'Animal', 'statusSaude', 'Em Tratamento');

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Instituto Caramelo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="dashboard-style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand primary-text" href="adminDashboard.php"><i class="fas fa-paw me-2"></i>Instituto Caramelo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="adminDashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroPessoa.php">Pessoas</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroAnimal.html">Animais</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroVeterinario.html">Veterinários</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroAdocao.html">Adoções</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroCastracao.html">Castrações</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroPatrocinador.html">Patrocinadores</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroApadrinhamento.html">Apadrinhamentos</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroUsuario.html">Usuários</a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="index.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Dashboard</h1>
        <p class="lead">Visão geral do sistema do instituto.</p>
        
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalPessoas ?></h4>
                        <p class="card-text">Pessoas Cadastradas</p>
                    </div>
                </div>
            </div>
             <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-dog fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalAnimais ?></h4>
                        <p class="card-text">Total de Animais</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-hand-holding-heart fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalAdocoes ?></h4>
                        <p class="card-text">Adoções Realizadas</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-building fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalPatrocinadores ?></h4>
                        <p class="card-text">Patrocinadores</p>
                    </div>
                </div>
            </div>
             <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-ambulance fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalResgates ?></h4>
                        <p class="card-text">Resgates Realizados</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-heartbeat fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalEmTratamento ?></h4>
                        <p class="card-text">Animais em Tratamento</p>
                    </div>
                </div>
            </div>
             <div class="col-lg-3 col-md-6 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-cut fa-3x primary-text mb-3"></i>
                        <h4 class="card-title"><?= $totalCastracoes ?></h4>
                        <p class="card-text">Castrações Registradas</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>