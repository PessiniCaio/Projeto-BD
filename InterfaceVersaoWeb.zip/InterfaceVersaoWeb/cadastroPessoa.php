<?php
// Passo 1: Ativa a exibição de todos os erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Inclui a conexão (que agora também tem um teste de falha)
require_once 'conexao.php';

// Variável para armazenar os dados da pessoa em modo de edição
$pessoa_para_editar = null;
$edit_mode = false;

// --- LÓGICA DO CRUD ---

// PRIMEIRO, VERIFICAMOS SE O FORMULÁRIO FOI ENVIADO
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Se um idPessoa foi enviado, é um UPDATE (Atualização)
    if (!empty($_POST['idPessoa'])) {
        // Lógica de UPDATE
        $idPessoa = $_POST['idPessoa'];
        $idEndereco = $_POST['idEndereco'];
        $idCidade = $_POST['idCidade'];

        $pdo->beginTransaction();
        try {
            $sql_cidade = "UPDATE Cidade SET nome = ?, uf = ? WHERE idCidade = ?";
            $pdo->prepare($sql_cidade)->execute([$_POST['cidade'], $_POST['uf'], $idCidade]);

            $sql_endereco = "UPDATE Endereco SET logradouro = ?, bairro = ?, numero = ?, complemento = ? WHERE idEndereco = ?";
            $pdo->prepare($sql_endereco)->execute([$_POST['logradouro'], $_POST['bairro'], $_POST['numero'], $_POST['complemento'], $idEndereco]);

            $sql_pessoa = "UPDATE Pessoa SET nome = ?, telefone = ?, sexo = ?, cpf = ? WHERE idPessoa = ?";
            $pdo->prepare($sql_pessoa)->execute([$_POST['nome'], $_POST['telefone'], $_POST['sexo'], $_POST['cpf'], $idPessoa]);

            $pdo->commit();
            header("Location: cadastroPessoa.php?status=editado");
            exit();

        } catch (PDOException $e) {
            $pdo->rollBack();
            die("ERRO AO ATUALIZAR NO BANCO: " . $e->getMessage());
        }

    } else { // Se não tem idPessoa, é um CREATE (Criação)
        // Lógica de CREATE
        $pdo->beginTransaction();
        try {
            $sql_cidade = "INSERT INTO Cidade (nome, uf) VALUES (?, ?)";
            $stmt_cidade = $pdo->prepare($sql_cidade);
            $stmt_cidade->execute([$_POST['cidade'], $_POST['uf']]);
            $idCidade = $pdo->lastInsertId();

            $sql_endereco = "INSERT INTO Endereco (idCidade, logradouro, bairro, numero, complemento) VALUES (?, ?, ?, ?, ?)";
            $stmt_endereco = $pdo->prepare($sql_endereco);
            $stmt_endereco->execute([$idCidade, $_POST['logradouro'], $_POST['bairro'], $_POST['numero'], $_POST['complemento']]);
            $idEndereco = $pdo->lastInsertId();

            $sql_pessoa = "INSERT INTO Pessoa (idEndereco, nome, telefone, sexo, cpf) VALUES (?, ?, ?, ?, ?)";
            $stmt_pessoa = $pdo->prepare($sql_pessoa);
            $stmt_pessoa->execute([$idEndereco, $_POST['nome'], $_POST['telefone'], $_POST['sexo'], $_POST['cpf']]);

            $pdo->commit();
            header("Location: cadastroPessoa.php?status=cadastrado");
            exit();

        } catch (PDOException $e) {
            $pdo->rollBack();
            // Esta mensagem de erro é a mais provável de aparecer.
            // Ex: "ERRO AO INSERIR NO BANCO: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry '123.456.789-00' for key 'cpf'"
            die("ERRO AO INSERIR NO BANCO: " . $e->getMessage());
        }
    }
}

// Lógica de EDIT (buscar dados para preencher o formulário)
if (isset($_GET['edit_id']) && !isset($_POST['idPessoa'])) {
    $edit_mode = true;
    $id = $_GET['edit_id'];
    $sql = "SELECT p.*, e.*, c.*, c.nome as nome_cidade FROM Pessoa p
            JOIN Endereco e ON p.idEndereco = e.idEndereco
            JOIN Cidade c ON e.idCidade = c.idCidade
            WHERE p.idPessoa = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $pessoa_para_editar = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Lógica de DELETE
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $sql = "DELETE FROM Pessoa WHERE idPessoa = ?";
    $pdo->prepare($sql)->execute([$id]);
    header("Location: cadastroPessoa.php?status=deletado");
    exit();
}

// Lógica de READ (listar todos para a tabela)
$sql_read = "SELECT p.idPessoa, p.nome, p.cpf, e.logradouro, e.numero, c.nome as cidade, c.uf
             FROM Pessoa p
             JOIN Endereco e ON p.idEndereco = e.idEndereco
             JOIN Cidade c ON e.idCidade = c.idCidade
             ORDER BY p.idPessoa ASC";
$pessoas = $pdo->query($sql_read)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Pessoas - Instituto Caramelo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="dashboard-style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand primary-text" href="adminDashboard.php"><i class="fas fa-paw me-2"></i>Instituto Caramelo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                 <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="adminDashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="cadastroPessoa.php">Pessoas</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroAnimal.php">Animais</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroVeterinario.php">Veterinários</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroAdocao.php">Adoções</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroCastracao.php">Castrações</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroPatrocinador.php">Patrocinadores</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroApadrinhamento.php">Apadrinhamentos</a></li>
                    <li class="nav-item"><a class="nav-link" href="cadastroUsuario.php">Usuários</a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="index.html">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Gerenciamento de Pessoas</h1>

        <div class="card mb-5">
            <div class="card-header">
                <h5>
                    <i class="fas <?= $edit_mode ? 'fa-edit' : 'fa-plus' ?> me-2"></i>
                    <?= $edit_mode ? 'Editar Pessoa' : 'Adicionar Nova Pessoa' ?>
                </h5>
            </div>
            <div class="card-body">
                <form action="cadastroPessoa.php" method="POST">
                    <input type="hidden" name="idPessoa" value="<?= $pessoa_para_editar['idPessoa'] ?? '' ?>">
                    <input type="hidden" name="idEndereco" value="<?= $pessoa_para_editar['idEndereco'] ?? '' ?>">
                    <input type="hidden" name="idCidade" value="<?= $pessoa_para_editar['idCidade'] ?? '' ?>">
                    
                    <h5 class="mb-3">Dados Pessoais</h5>
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($pessoa_para_editar['nome'] ?? '') ?>" required>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="cpf" class="form-label">CPF</label>
                            <input type="text" class="form-control" id="cpf" name="cpf" value="<?= htmlspecialchars($pessoa_para_editar['cpf'] ?? '') ?>" maxlength="14" required>
                        </div>
                        <div class="col-md-4">
                            <label for="telefone" class="form-label">Telefone</label>
                            <input type="tel" class="form-control" id="telefone" name="telefone" value="<?= htmlspecialchars($pessoa_para_editar['telefone'] ?? '') ?>" maxlength="15">
                        </div>
                        <div class="col-md-4">
                            <label for="sexo" class="form-label">Sexo</label>
                            <select id="sexo" name="sexo" class="form-select">
                                <option value="Masculino" <?= (($pessoa_para_editar['sexo'] ?? '') == 'Masculino') ? 'selected' : '' ?>>Masculino</option>
                                <option value="Feminino" <?= (($pessoa_para_editar['sexo'] ?? '') == 'Feminino') ? 'selected' : '' ?>>Feminino</option>
                                <option value="Outro" <?= (($pessoa_para_editar['sexo'] ?? '') == 'Outro') ? 'selected' : '' ?>>Outro</option>
                            </select>
                        </div>
                    </div>
                    
                    <hr>
                    <h5 class="mb-3">Endereço</h5>
                    <div class="row mb-3">
                        <div class="col-md-9"><label for="cidade" class="form-label">Cidade</label><input type="text" class="form-control" id="cidade" name="cidade" value="<?= htmlspecialchars($pessoa_para_editar['nome_cidade'] ?? '') ?>" required></div>
                        <div class="col-md-3"><label for="uf" class="form-label">UF</label><input type="text" class="form-control" id="uf" name="uf" value="<?= htmlspecialchars($pessoa_para_editar['uf'] ?? '') ?>" maxlength="2" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-9"><label for="logradouro" class="form-label">Logradouro</label><input type="text" class="form-control" id="logradouro" name="logradouro" value="<?= htmlspecialchars($pessoa_para_editar['logradouro'] ?? '') ?>" required></div>
                        <div class="col-md-3"><label for="numero" class="form-label">Número</label><input type="text" class="form-control" id="numero" name="numero" value="<?= htmlspecialchars($pessoa_para_editar['numero'] ?? '') ?>" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6"><label for="bairro" class="form-label">Bairro</label><input type="text" class="form-control" id="bairro" name="bairro" value="<?= htmlspecialchars($pessoa_para_editar['bairro'] ?? '') ?>" required></div>
                        <div class="col-md-6"><label for="complemento" class="form-label">Complemento</label><input type="text" class="form-control" id="complemento" name="complemento" value="<?= htmlspecialchars($pessoa_para_editar['complemento'] ?? '') ?>"></div>
                    </div>

                    <button type="submit" class="btn btn-primary custom-btn mt-3">
                        <?= $edit_mode ? 'Atualizar Pessoa' : 'Salvar Pessoa' ?>
                    </button>
                    <?php if ($edit_mode): ?>
                        <a href="cadastroPessoa.php" class="btn btn-secondary mt-3">Cancelar Edição</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h5><i class="fas fa-list me-2"></i>Pessoas Cadastradas</h5></div>
            <div class="card-body table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th><th>Nome</th><th>CPF</th><th>Endereço Completo</th><th class="text-end">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pessoas as $pessoa): ?>
                            <tr>
                                <td><?= htmlspecialchars($pessoa['idPessoa']) ?></td>
                                <td><?= htmlspecialchars($pessoa['nome']) ?></td>
                                <td><?= htmlspecialchars($pessoa['cpf']) ?></td>
                                <td><?= htmlspecialchars($pessoa['logradouro'] . ', ' . $pessoa['numero'] . ' - ' . $pessoa['cidade'] . '/' . $pessoa['uf']) ?></td>
                                <td class="text-end">
                                    <a href="cadastroPessoa.php?edit_id=<?= $pessoa['idPessoa'] ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="cadastroPessoa.php?delete_id=<?= $pessoa['idPessoa'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir? Isso não pode ser desfeito.');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="formatter.js"></script>
</body>
</html>