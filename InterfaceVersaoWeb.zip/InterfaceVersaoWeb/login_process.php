<?php
// Arquivo: login_process.php

// Inicia a sessão para podermos usar variáveis de sessão no futuro (boa prática)
session_start();

// Dados do formulário
$usuario_form = $_POST['usuario'];
$senha_form = $_POST['senha'];

// --- Validação Simples ---
// Em um sistema real, você buscaria o usuário e a senha (criptografada) no banco de dados.
// Para este exemplo, vamos usar um usuário "admin" fixo.

$usuario_correto = 'admin';
$senha_correta = 'admin'; // Em um sistema real, NUNCA guarde a senha assim.

// Verifica se o usuário e a senha batem
if ($usuario_form === $usuario_correto && $senha_form === $senha_correta) {
    
    // Se estiverem corretos, cria uma variável de sessão para identificar o usuário
    $_SESSION['usuario_logado'] = $usuario_correto;
    
    // Redireciona o usuário para o dashboard do admin
    header("Location: adminDashboard.php");
    exit(); // Encerra o script para garantir que o redirecionamento aconteça

} else {
    // Se estiverem errados, redireciona de volta para a tela de login com uma mensagem de erro
    header("Location: index.php?erro=1");
    exit();
}
?>